#include <windows.h>
#include <GL/glut.h>

GLfloat angle = 0.0f;
void initGL()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

void idle()
{
  glutPostRedisplay();
}

void drawBlade(int a)
{
    if(a==1)
    {
      glRotatef(45.0f, 0.0f, 0.0f, -1.0f);
      glBegin(GL_POLYGON);
      glColor3f(0.5f, 0.5f, 0.5f);
      glVertex2f(0.0f, 0.0f);
      glVertex2f( 0.0f, 40.0f);
      glVertex2f(24.0f,  40.0f);
      glVertex2f(53.0f, 60.0f);
      glVertex2f(206.0f, 5.0f);
      glVertex2f(206.0f, 0.0f);
      glEnd();
    }
    if(a==2)
    {
      glRotatef(30.0f, 0.0f, 0.0f, 1.0f);
      glTranslatef(20.0f, -5.5f, 0.0f);
      glBegin(GL_POLYGON);
      glColor3f(0.5f, 0.5f, 0.5f);
      glVertex2f(0.0f, 40.0f);
      glVertex2f(-40.0f, 40.0f);
      glVertex2f(-40.0f, 64.0f);
      glVertex2f(-60.0f, 93.0f);
      glVertex2f(-5.0f, 246.0f);
      glVertex2f(0.0f, 246.0f);
      glEnd();
    }
    if(a==3)
    {
      glRotatef(31.0f, 0.0f, 0.0f, 1.0f);
      glTranslatef(-14.0f, 55.0f, 0.0f);
      glBegin(GL_POLYGON);
      glColor3f(0.5f, 0.5f, 0.5f);
      glVertex2f(0.0f, 0.0f);
      glVertex2f( 0.0f, -40.0f);
      glVertex2f(-24.0f,  -40.0f);
      glVertex2f(-53.0f, -60.0f);
      glVertex2f(-206.0f, -5.0f);
      glVertex2f(-206.0f, 0.0f);
      glEnd();
    }

}

void display() {
   glClear(GL_COLOR_BUFFER_BIT);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glPushMatrix();
   glTranslatef(0.6f, -0.6f, 0.0f);
   glRotatef(180.0f + angle, 0.0f, 0.0f, -1.0f);
    drawBlade(1);
    drawBlade(2);
    drawBlade(3);
   glPopMatrix();
   glutSwapBuffers();
   angle += 0.2f;
}
void reshape(GLsizei width, GLsizei height) {
   if (height == 0) height = 300;
   GLfloat aspect = (GLfloat)width / (GLfloat)height;
   glViewport(0, 0, width, height);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   if (width >= height) {
      gluOrtho2D(-300.0 * aspect, 300.0 * aspect, -300.0, 300.0);
   } else {
     gluOrtho2D(-300.0, 300.0, -300.0 / aspect, 300.0 / aspect);
   }
}
int main(int argc, char** argv) {
   glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE);
   glutInitWindowSize(640, 480);
   glutInitWindowPosition(0, 0);

      glutCreateWindow("Animation via Idle Function");
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutIdleFunc(idle);
   initGL();
   glutMainLoop();
   return 0;
}
