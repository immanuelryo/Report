#include <windows.h>
#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h>
#include <cmath>

void myWireSphere(GLfloat radius, int slices, int stacks) {
  glPushMatrix();
  glRotatef(-90.0, 1.0, 0.0, 0.0);
  glutWireSphere(radius, slices, stacks);
  glPopMatrix();
}
/* Pada sistem tata surya hanya mengacu pada "tahun" dah "hari" sebagai global
variabelnya.
Sebenarnya planet hanya berevolusi terhadap matahari dengan increment 5 derajat
("tahun") dan rotasi planet pada titik aksisnya increment 10 derajat ("hari").*/

static int tahun = 1, bulan =12, hari =136;
void display() {
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glPushMatrix();
  // gambr matahari: bola kuning dengan radius 1 terhadap pusatnya.
  glColor3f(1.0, 1.0, 0.0);
  glRotatef(1,0,0,1);
  myWireSphere(1.0, 15, 15);
  // gambar planet : bola biru dengan radius 0.2, jarak 4 unit dari matahari dengan kutub berwarna putih pada axis.
  glRotatef((GLfloat)tahun, 0.0, 1.0, 0.0);
  glTranslatef (4.0, 0.0, 0.0);
  glRotatef((GLfloat)hari, 0.0, 1.0, 0.0);
  glColor3f(0.0, 0.0, 1.0);
  myWireSphere(0.2, 15, 15);
  glColor3f(1, 1, 1);
  glBegin(GL_LINES);
    glVertex3f(0, -0.3, 0);
    glVertex3f(0, 0.3, 0);
  glEnd();
  glRotatef((GLfloat)tahun, 0.0, 1.0, 0.0);
  glTranslatef (0.5, 0.0, 0.0);
  //glRotatef((GLfloat)hari, 0.0, 1.0, 0.0);
  myWireSphere(0.1,10,10);
  glPopMatrix();
  glFlush();
  glutSwapBuffers();
}
static GLfloat u = 0.0;
static GLfloat du = 0.1;
void timer(int v) {
      u += du;
  hari = (hari + 1) % 360;
//month=(month +2) % 360;
  tahun = (tahun + 2) % 360;
  glLoadIdentity();
  gluLookAt(5,5,5,0,0,0,0,10,0);
//gluLookAt(20*cos(u/8.0)+12,5*sin(u/8.0)+1,10*cos(u/8.0)+2, 0,0,0, 0,1,0);
  glutPostRedisplay();
  glutTimerFunc(1000/60, timer, v);
}
void reshape(GLint w, GLint h) {
  glViewport(0, 0, w, h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(60.0, (GLfloat)w/(GLfloat)h, 1.0, 40.0);
  glMatrixMode(GL_MODELVIEW);
}
int main(int argc, char** argv) {
  glutInit(&argc, argv);
  glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowSize(800, 600);
  glutCreateWindow("Planet");
  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutTimerFunc(100, timer, 0);
  glEnable(GL_DEPTH_TEST);
  glutMainLoop();
}
